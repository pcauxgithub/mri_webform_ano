MRI Webform IP-Anoymizer

What does the Module do:
The module saves IP addresses of web form submissions anonymously.
The following options are available:
	Overwriting the last IP octet with "1111".
	Overwriting the last IP octet with the calculated cross-section. Example: From .145 to .10.
	Overwriting the last two IP octets with the calculated cross-section. Example: From 105.17 to 6.8.
	
The module operates on a global level. An individual configuration for individual webforms is not possible.
The module contains an IP-Adress Testmodus (Config Form). It´s possible to save an imaginary IP-Adress for tests purposes.
Permissions for Viewing and Editing of the Module Config Mask are available.



