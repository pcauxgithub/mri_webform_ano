(function ($) {
  // code here
}(jQuery));
